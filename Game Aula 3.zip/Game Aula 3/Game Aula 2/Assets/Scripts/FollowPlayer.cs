﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FollowPlayer : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    public GameObject player;
    private Vector3 offset = new Vector3(0, 5, -7);

    // Update is called once per frame
    void LateUpdate()
    {
        // transform.position = player.transform.position;  Fazendo a camera seguir o jogador
        // transform.position = player.transform.position + new Vector3(0, 5, -7); Fazendo a camera ficar na posição atrás do jogador
        transform.position = player.transform.position + offset; // Fazendo a mesma cosia, porem colocando os valores do Vector3 em uma variavel offset
    }
}
